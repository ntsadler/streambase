# Streambase CRM v1

Local-first playlist intelligence and outreach CRM for independent artists.

## Adds
- Curator profiles
- Playlist records attached to curators
- Contact method stack: email, Instagram, website, submission page, Linktree/Beacons/Carrd
- Outreach history events
- Priority scoring
- Outreach drafts
- CSV export
- Local SQLite database

## Run
```bash
cd streambase-crm
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```
