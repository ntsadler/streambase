import json, pandas as pd, streamlit as st
from src.database import init_db,get_curator_profiles,get_all_playlists,add_outreach_event,update_playlist_status
from src.ingest_playlists import load_playlists_from_text,playlists_from_links,save_raw_json
from src.pipeline import process_playlists
from src.web_enricher import enrich_playlist_from_url
st.set_page_config(page_title='Streambase',page_icon='🎛️',layout='wide')
st.title('🎛️ Streambase')
st.caption('Playlist intelligence, curator contact stack, and outreach CRM for independent music growth.')
init_db()
with st.sidebar:
    st.header('Settings'); do_web=st.toggle('Fetch public contact info',value=True); st.caption('Email is the main lane. Instagram DM and submission pages are backup lanes.'); st.divider(); st.write('Outreach stack: Email → Instagram DM → Submission page')
tab_import,tab_results,tab_curators=st.tabs(['Import & Analyze','Playlist Results','Curator CRM'])
if 'playlists' not in st.session_state: st.session_state.playlists=[]
if 'report' not in st.session_state: st.session_state.report=None
def df_session():
    df=pd.DataFrame(st.session_state.playlists) if st.session_state.playlists else pd.DataFrame(columns=['playlist_name','playlist_url','follower_count','curator_name','related_artists','last_updated','spotify_description'])
    for col in ['playlist_name','playlist_url','follower_count','curator_name','related_artists','last_updated','spotify_description']:
        if col not in df.columns: df[col]=0 if col=='follower_count' else ''
    return df
with tab_import:
    st.subheader('Import playlist data')
    mode=st.radio('Choose input method',['Paste Spotify playlist links','Upload CSV'],horizontal=True)
    if mode=='Paste Spotify playlist links':
        raw=st.text_area('Spotify playlist links',height=160,placeholder='https://open.spotify.com/playlist/...')
        c1,c2=st.columns(2)
        with c1:
            if st.button('Load pasted links',use_container_width=True): st.session_state.playlists=playlists_from_links(raw); st.success(f"Loaded {len(st.session_state.playlists)} playlist links.")
        with c2:
            if st.button('Fetch Spotify Details',use_container_width=True):
                if not st.session_state.playlists: st.error('Load playlist links first.')
                else:
                    updated=[]; prog=st.progress(0)
                    for i,row in enumerate(st.session_state.playlists):
                        row=dict(row); meta=enrich_playlist_from_url(row.get('playlist_url',''))
                        if meta.get('playlist_name') and not row.get('playlist_name'): row['playlist_name']=meta['playlist_name']
                        if meta.get('curator_name') and not row.get('curator_name'): row['curator_name']=meta['curator_name']
                        if meta.get('spotify_description'): row['spotify_description']=meta['spotify_description']
                        updated.append(row); prog.progress((i+1)/max(len(st.session_state.playlists),1))
                    st.session_state.playlists=updated; st.success('Spotify details fetched where available.')
    else:
        up=st.file_uploader('Choose CSV file',type=['csv'])
        if up: st.session_state.playlists=load_playlists_from_text(up.read().decode('utf-8-sig')); st.success(f"Loaded {len(st.session_state.playlists)} playlists from CSV.")
    if st.session_state.playlists:
        st.markdown('#### Edit details before analysis')
        st.caption('For a useful score, add related artists like `MGMT; LCD Soundsystem; Tame Impala` and follower counts if you know them.')
        edited=st.data_editor(df_session(),use_container_width=True,num_rows='dynamic')
        st.session_state.playlists=edited.fillna('').to_dict(orient='records')
        c1,c2=st.columns(2)
        with c1:
            if st.button('Analyze & Save to CRM',type='primary',use_container_width=True):
                with st.spinner('Scoring playlists, finding contacts, and saving curator profiles...'):
                    save_raw_json(st.session_state.playlists); st.session_state.report=process_playlists(st.session_state.playlists,do_web_enrichment=do_web)
                st.success('Analysis complete. Curator CRM updated.')
        with c2:
            if st.button('Clear Import',use_container_width=True): st.session_state.playlists=[]; st.session_state.report=None; st.rerun()
with tab_results:
    st.subheader('Playlist results')
    rep=st.session_state.report; rows=get_all_playlists()
    if rep:
        a,b,c=st.columns(3); a.metric('Processed',rep['total_playlists_processed']); b.metric('Contactable',rep['contactable_curators_count']); c.metric('% contactable',f"{rep['contactable_curators_percent']}%")
    if rows:
        df=pd.DataFrame(rows); st.dataframe(df,use_container_width=True,hide_index=True)
        st.download_button('Download CRM Playlists CSV',df.to_csv(index=False).encode('utf-8'),'streambase_playlists.csv','text/csv')
    else: st.info('No playlists saved yet.')
    if rep:
        st.subheader('Outreach drafts from latest run')
        for item in sorted(rep['processed_playlists'],key=lambda x:x.get('final_score',0),reverse=True)[:10]:
            with st.expander(f"{item.get('playlist_name') or 'Unnamed'} — {item.get('final_score')}"):
                st.write(f"Curator: {item.get('curator_name') or 'Unknown'}")
                st.write(f"Email: {item.get('email') or 'Not found'} | Instagram: {item.get('instagram') or 'Not found'} | Submission: {item.get('submission_page') or 'Not found'}")
                st.text_area('Email',item.get('email_message',''),height=160,key=f"e_{item.get('playlist_url')}")
                st.text_area('Instagram DM',item.get('instagram_dm',''),height=90,key=f"d_{item.get('playlist_url')}")
                st.text_area('Submission note',item.get('submission_note',''),height=90,key=f"s_{item.get('playlist_url')}")
with tab_curators:
    st.subheader('Curator CRM')
    curators=get_curator_profiles()
    if not curators: st.info('No curators saved yet.')
    for cur in curators:
        playlists=cur.get('playlists',[]); methods=cur.get('contact_methods',[]); events=cur.get('outreach_events',[]); best=max([p.get('final_score') or 0 for p in playlists],default=0)
        with st.expander(f"{cur['display_name']} · {len(playlists)} playlist(s) · best score {best}"):
            l,r=st.columns([1,1])
            with l:
                st.markdown('#### Playlists'); st.dataframe(pd.DataFrame(playlists),use_container_width=True,hide_index=True) if playlists else st.caption('No playlists.')
                st.markdown('#### Contact methods'); st.dataframe(pd.DataFrame(methods),use_container_width=True,hide_index=True) if methods else st.caption('No contact methods found.')
            with r:
                top=playlists[0] if playlists else {}; pid=int(top.get('id') or 0); cid=int(cur['id'])
                st.markdown('#### Outreach actions')
                em=next((m for m in methods if m['type']=='email'),None); ig=next((m for m in methods if m['type']=='instagram'),None); sub=next((m for m in methods if m['type']=='submission_page'),None)
                if em: st.link_button('Open Email',f"mailto:{em['value']}",use_container_width=True)
                if ig: st.link_button('Open Instagram',ig['value'],use_container_width=True)
                if sub: st.link_button('Open Submission Page',sub['value'],use_container_width=True)
                ch=st.selectbox('Log outreach channel',['email','instagram','submission_page','website'],key=f'ch_{cid}')
                ev=st.selectbox('Log event',['drafted','sent','replied','submitted','added_song','ignored'],key=f'ev_{cid}')
                msg=st.text_area('Notes/message',key=f'msg_{cid}',height=100)
                if st.button('Log Outreach Event',key=f'log_{cid}',use_container_width=True):
                    add_outreach_event(cid,pid,ch,ev,msg)
                    if pid and ev in {'sent','submitted','ignored'}: update_playlist_status(pid,ev)
                    st.success('Outreach event logged.'); st.rerun()
                st.markdown('#### History'); st.dataframe(pd.DataFrame(events),use_container_width=True,hide_index=True) if events else st.caption('No outreach history yet.')
