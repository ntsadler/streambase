import json
from collections import Counter
from pathlib import Path
from src.database import init_db, upsert_playlist, get_or_create_curator, upsert_contact_method
from src.outreach_generator import generate_outreach
from src.scorer import score_playlist
from src.similarity_engine import compute_similarity, split_terms, suggest_expanded_band_candidates
from src.web_enricher import enrich_contact_info
def process_playlists(playlists, do_web_enrichment=True):
    init_db(); processed=[]; related=Counter()
    for playlist in playlists:
        playlist=dict(playlist); contact={}
        if do_web_enrichment: contact=enrich_contact_info(playlist.get('playlist_name',''),playlist.get('curator_name',''),playlist.get('playlist_url',''))
        if contact.get('playlist_name_found') and not playlist.get('playlist_name'): playlist['playlist_name']=contact['playlist_name_found']
        if contact.get('curator_name_found') and not playlist.get('curator_name'): playlist['curator_name']=contact['curator_name_found']
        if contact.get('spotify_description') and not playlist.get('spotify_description'): playlist['spotify_description']=contact['spotify_description']
        sim=compute_similarity(playlist); scored=score_playlist(sim['similarity_score'],playlist.get('follower_count',0),playlist.get('last_updated',''),contact); msg=generate_outreach(playlist,sim)
        rec={**playlist,'similarity_score':sim['similarity_score'],'similarity_breakdown':sim['breakdown'],'final_score':scored['final_score'],'priority':scored['priority'],'email':contact.get('email'),'instagram':contact.get('instagram'),'website':contact.get('website'),'submission_page':contact.get('submission_page'),'link_hub':contact.get('link_hub'),'contact_confidence':contact.get('confidence_score',0),'contact_methods':contact.get('contact_methods',[]),**msg}
        cid=get_or_create_curator(rec.get('curator_name') or 'Unknown Curator')
        pid=upsert_playlist({'curator':rec.get('curator_name'),'name':rec.get('playlist_name'),'url':rec.get('playlist_url'),'followers':rec.get('follower_count'),'related_artists':rec.get('related_artists'),'spotify_description':rec.get('spotify_description'),'similarity_score':rec.get('similarity_score'),'final_score':rec.get('final_score'),'priority':rec.get('priority')})
        for m in rec['contact_methods']: upsert_contact_method(cid,m)
        rec['curator_id']=cid; rec['playlist_id']=pid
        for a in split_terms(playlist.get('related_artists','')): related[a]+=1
        processed.append(rec)
    top=sorted(processed,key=lambda x:x.get('final_score',0),reverse=True)[:10]; contactable=[p for p in processed if p.get('email') or p.get('instagram') or p.get('website') or p.get('submission_page')]
    report={'total_playlists_processed':len(processed),'contactable_curators_count':len(contactable),'contactable_curators_percent':round((len(contactable)/len(processed))*100,2) if processed else 0,'top_10_playlists_by_score':top,'most_common_related_artists_found':related.most_common(20),'expanded_band_candidates':suggest_expanded_band_candidates(processed)['suggested_new_artists'],'processed_playlists':processed}
    Path('data/report.json').write_text(json.dumps(report,indent=2),encoding='utf-8'); return report
