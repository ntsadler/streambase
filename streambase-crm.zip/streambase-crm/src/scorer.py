from datetime import datetime
def follower_fit_score(f):
    f=int(f or 0)
    if f<=0: return 40
    if 1000<=f<=75000: return 100
    if 250<=f<1000: return 75
    if 75001<=f<=250000: return 65
    if f>250000: return 35
    return 50
def recency_score(v):
    if not v: return 50
    try: days=(datetime.now()-datetime.fromisoformat(v[:10])).days
    except ValueError: return 50
    return 100 if days<=30 else 80 if days<=90 else 65 if days<=180 else 45 if days<=365 else 20
def contactability_score(c):
    return 100 if c.get('email') else 75 if c.get('instagram') else 65 if c.get('submission_page') else 50 if c.get('website') else 0
def score_playlist(similarity_score,follower_count,recency='',contact=None):
    contact=contact or {}; fs=follower_fit_score(follower_count); rs=recency_score(recency); cs=contactability_score(contact)
    final=similarity_score*.5+fs*.2+rs*.2+cs*.1
    return {'final_score':round(final,2),'priority':'high priority' if final>=80 else 'medium priority' if final>=50 else 'ignore','breakdown':{'similarity':round(similarity_score,2),'follower_fit':fs,'recency':rs,'contactability':cs}}
