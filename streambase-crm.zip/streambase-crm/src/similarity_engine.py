import json
from collections import Counter
from difflib import SequenceMatcher
from pathlib import Path
def refs(path='data/band_references.json'): return json.loads(Path(path).read_text(encoding='utf-8'))
def split_terms(text): return [x.strip() for x in (text or '').replace('|',';').replace(',',';').split(';') if x.strip()]
def ratio(a,b): return SequenceMatcher(None,a.lower(),b.lower()).ratio()
def matches(h,n): return n.lower() in h.lower() or ratio(h,n)>=0.82
def compute_similarity(playlist, refs_path='data/band_references.json'):
    r=refs(refs_path); hay=' '.join(str(playlist.get(k,'')) for k in ['playlist_name','curator_name','related_artists','spotify_description'])
    breakdown=[]; score=0.0
    for band,w in r.get('core_bands',{}).items():
        if matches(hay,band): pts=32*w; score+=pts; breakdown.append({'match':band,'type':'core_band','points':round(pts,2)})
    for band,w in r.get('expanded_bands',{}).items():
        if matches(hay,band): pts=22*w; score+=pts; breakdown.append({'match':band,'type':'expanded_band','points':round(pts,2)})
    for tag,w in r.get('vibe_tags',{}).items():
        if matches(hay,tag): pts=12*w; score+=pts; breakdown.append({'match':tag,'type':'vibe_tag','points':round(pts,2)})
    return {'similarity_score':min(100,round(score,2)),'breakdown':breakdown,'explanation':'Matched against reference universe.'}
def suggest_expanded_band_candidates(playlists, refs_path='data/band_references.json'):
    r=refs(refs_path); known={*r.get('core_bands',{}),*r.get('expanded_bands',{})}; kl={k.lower() for k in known}; c=Counter()
    for p in playlists:
        if float(p.get('final_score',0) or 0)<70: continue
        for a in split_terms(str(p.get('related_artists',''))):
            if a.lower() not in kl: c[a]+=1
    return {'suggested_new_artists':[{'artist':a,'appearances_in_high_scoring_playlists':n,'confidence_score':min(100,40+n*15)} for a,n in c.most_common(20)]}
